﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05Xml
{
    public class Continent
    {
        public string ContinentName { get; set; }

        public int CityNumber { get; set; }

        public double AvgPopulation { get; set; }

        public decimal AvgArea { get; set; }
    }

}
