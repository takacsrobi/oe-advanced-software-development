﻿// Egy XML fájl tartalmazza 20 világváros nevét, népességét és területét,
// valamint a földrész nevét, amelyen található! Olvassuk be az XML fájlt!


using _05Xml;
using System.Xml.Linq;

List<city> cities = new List<city>();

XDocument xdoc = XDocument.Load("cities.xml");

foreach (var item in xdoc.Descendants("city"))
{
    cities.Add(new city()
    {
        name = item.Element("name").Value,
        area = decimal.Parse(item.Element("area").Value),
        population = uint.Parse(item.Element("population").Value),
        continent = item.Element("continent").Value,
    });
}

// Egy LINQ lekérdezés segítségével állapítsuk meg minden földrészre a benne található városok számát,
// átlagos területét és lakosságát!

// Az eredményt típusos gyűjteménykét kezeljük és mentsük el XML fájlba!

var q = from x in cities
        group x by x.continent into g
        select new Continent()
        {
            ContinentName = g.Key,
            CityNumber = g.Count(),
            AvgPopulation = g.Average(t => t.population),
            AvgArea = g.Average(t => t.area)
        };

XDocument xdoc2 = new XDocument();
XElement root = new XElement("Continents");
xdoc2.Add(root);

foreach (var item in q)
{
    XElement sub = new XElement("Continent");
    sub.Add(new XElement("ContinentName", item.ContinentName));
    sub.Add(new XElement("CityNumber", item.CityNumber));
    sub.Add(new XElement("AvgPopulation", item.AvgPopulation));
    sub.Add(new XElement("AvgArea", item.AvgArea));
    root.Add(sub);
}

xdoc2.Save("continent.xml");


