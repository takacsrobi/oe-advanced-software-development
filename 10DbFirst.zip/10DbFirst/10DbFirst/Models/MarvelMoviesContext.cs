﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace _10DbFirst.Models;

public partial class MarvelMoviesContext : DbContext
{
    public MarvelMoviesContext()
    {
    }

    public MarvelMoviesContext(DbContextOptions<MarvelMoviesContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Director> Directors { get; set; }

    public virtual DbSet<Movie> Movies { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MarvelMovies;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Director>(entity =>
        {
            entity.HasKey(e => e.DirectorId).HasName("Directors_primary_key");

            entity.Property(e => e.DirectorId).HasColumnType("numeric(4, 0)");
            entity.Property(e => e.DirectorName)
                .HasMaxLength(240)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Movie>(entity =>
        {
            entity.HasKey(e => e.MovieId).HasName("Movies_primary_key");

            entity.Property(e => e.MovieId).HasColumnType("numeric(4, 0)");
            entity.Property(e => e.DirectorId).HasColumnType("numeric(4, 0)");
            entity.Property(e => e.Release).HasColumnType("date");
            entity.Property(e => e.Title)
                .HasMaxLength(240)
                .IsUnicode(false);

            entity.HasOne(d => d.Director).WithMany(p => p.Movies)
                .HasForeignKey(d => d.DirectorId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("Movies_directors_foreign_key");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
