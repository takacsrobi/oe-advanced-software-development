﻿using System;
using System.Collections.Generic;

namespace _10DbFirst.Models;

public partial class Director
{
    public decimal DirectorId { get; set; }

    public string? DirectorName { get; set; }

    public virtual ICollection<Movie> Movies { get; set; } = new List<Movie>();
}
