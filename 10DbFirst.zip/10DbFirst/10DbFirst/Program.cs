﻿//A mellékelt SQL script segítségével generáljunk egy DbFirst adatbázist!
//Hajtsuk végre rajta az alábbi lekérdezéseket:

using _10DbFirst.Models;
using Microsoft.EntityFrameworkCore;

string conn = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=MarvelMovies;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

var ctx = new MarvelMoviesContext();

var movies = ctx.Movies.Include(t => t.Director);


// - Írjuk ki a filmek címét és értékelését az értékelés szerint csökkenő sorrendben!
Console.WriteLine("Q1");
var q1 = from x in movies
         orderby x.Rating descending
         select new
         {
             Title = x.Title,
             Rating = x.Rating
         };
foreach (var item in q1)
{
    Console.WriteLine(item.Title + " - " + item.Rating);
}
Console.WriteLine();
Console.WriteLine();

// - Melyik a legjobban értékelt film?
Console.WriteLine("Q2");
var q2 = movies.OrderByDescending(t => t.Rating).FirstOrDefault();
Console.WriteLine(q2.Title);
Console.WriteLine();
Console.WriteLine();


// - Adott években mennyi volt az átlagos bevétel?
Console.WriteLine("Q3");

var q3 = from x in movies
         group x by ((DateTime)x.Release).Year into g
         orderby g.Average(z => z.Income) descending
         select new
         {
             Year = g.Key,
             AvgIncome = g.Average(z => z.Income)
         };
foreach (var item in q3)
{
    Console.WriteLine(item.Year + ": " + Math.Round((double)item.AvgIncome, 2));
}

Console.WriteLine();
Console.WriteLine();

// - Melyik rendező hány filmet rendezett?
Console.WriteLine("Q4");

foreach (var item in ctx.Directors.Include(z => z.Movies).OrderByDescending(t => t.Movies.Count))
{
    Console.WriteLine(item.DirectorName + ": " + item.Movies.Count);
}

Console.WriteLine();
Console.WriteLine();

// - Átlagosan mekkora bevételt hozott egy-egy rendező?
Console.WriteLine("Q5");
var q5 = from x in movies
         group x by x.Director.DirectorName into g
         orderby g.Average(z => z.Income) descending
         select new
         {
             Director = g.Key,
             AvgIncome = g.Average(z => z.Income)
         };
foreach (var item in q5)
{
    Console.WriteLine(item.Director + ": " + Math.Round((double)item.AvgIncome, 2));
}
Console.WriteLine();
Console.WriteLine();