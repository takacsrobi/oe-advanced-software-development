﻿//Két JSON fájl áll rendelkezésünkre. Az egyikben a dolgozók találhatóak névvel,
//fizetéssel, munkakörrel és a szervezeti egységükkel.
//A másikban a szervezeti egységek és a város, ahol találhatóak.

//Olvassuk be a két JSON fájlt objektumgyűjteménybe!

using _06Json.Models;
using Newtonsoft.Json;

List<Worker>? workers = JsonConvert.DeserializeObject<List<Worker>>(File.ReadAllText("workers.json"));
List<Department>? departments = JsonConvert.DeserializeObject<List<Department>>(File.ReadAllText("departments.json"));

// A két adatforráson végezzünk el JOIN-t a deparment alapján! Végezzük el az alábbi lekérdezést:
// Városonként mekkora az átlagfizetés és hányan dolgoznak ott?
// Az eredményt egy típusos gyűjteményként kérjük le, majd szerializáljuk JSON fájlba!

var q = from w in workers
        join d in departments
        on w.department equals d.department
        group w by d.location into g
        select new CityResult()
        {
            City = g.Key,
            AvgSalary = g.Average(t => t.salary),
            WorkerCount = g.Count()
        };

File.WriteAllText("city.json", JsonConvert.SerializeObject(q, Formatting.Indented));
