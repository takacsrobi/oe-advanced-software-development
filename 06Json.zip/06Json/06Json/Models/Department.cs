﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06Json.Models
{
    public class Department
    {
        public string department { get; set; }
        public string location { get; set; }
    }

}
