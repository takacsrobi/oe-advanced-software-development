﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06Json.Models
{

    public class Worker
    {
        public string name { get; set; }
        public int salary { get; set; }
        public string jobTitle { get; set; }
        public string department { get; set; }
    }

}
