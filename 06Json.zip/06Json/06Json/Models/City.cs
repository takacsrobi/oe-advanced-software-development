﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06Json.Models
{
    public class CityResult
    {
        public string City { get; set; }

        public double AvgSalary { get; set; }

        public int WorkerCount { get; set; }
    }
}
