﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recorder
{
    public class TranslationAttribute : Attribute
    {
        public string Value { get; set; }

        public TranslationAttribute(string value)
        {
            Value = value;
        }
    }
}
