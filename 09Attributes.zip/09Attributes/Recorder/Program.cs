﻿// Készítsünk reflexióval olyan függvényt, amely képes egy tetszőleges típus összes
// tulajdonságát bekérni párbeszédes formában!

// Helyezzünk el minden tulajdonság fölött egy olyan attribútumot, amely
// tartalmazza a kijelzőre írandó nevét az adott tulajdonságnak!


using Recorder;
using System.Reflection;

var p1 = new Person();
Record(p1);

;

void Record(object o)
{
    Type t = o.GetType();
	foreach (var prop in t.GetProperties())
    {
        var attr = prop.GetCustomAttribute<TranslationAttribute>();
        if (attr != null)
        {
            Console.Write(attr.Value + ": ");
        }
        else
        {
            Console.Write(prop.Name + ": ");
        }

        string value = Console.ReadLine();

        if (prop.PropertyType == typeof(string))
        {
            prop.SetValue(o, value);
        }
        else
        {
            var parseMethods = prop.PropertyType.GetMethods().Where(t => t.Name == "Parse");
            if (parseMethods != null)
            {
                var parser = parseMethods.First();
                var result = parser?.Invoke(null, new object[] { value });
                prop.SetValue(o, result);
            }
        }

        
    }
}

class Person
{
    public Person()
    {
        
    }

    [Translation("Név")]
    public string Name { get; set; }

    [Translation("Munkakör")]
    public string Job { get; set; }

    [Translation("Életkor")]
    public int Age { get; set; }
}