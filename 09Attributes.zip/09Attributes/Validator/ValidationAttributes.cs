﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Validator
{
    public class NotNullAttribute : Attribute
    {

    }

    public class StartUpperCase : Attribute
    {

    }

    public class LengthAttribute : Attribute
    {
        public LengthAttribute(int min, int max)
        {
            Min = min;
            Max = max;
        }

        public int Min { get; }

        public int Max { get; }
    }
}
