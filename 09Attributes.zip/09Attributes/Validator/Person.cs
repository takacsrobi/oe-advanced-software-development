﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Validator
{
    class Person
    {
        public Person(string name, string job)
        {
            Name = name;
            Job = job;
        }

        [NotNull]
        [StartUpperCase]
        [Length(3,10)]
        public string Name { get; set; }

        [NotNull]
        [Length(3,10)]
        public string Job { get; set; }

    }
}
