﻿// Készítsünk egy függvényt, amely képes validálni objektumokat!

// Hozzunk létre validációs attribútumokat, amelyeket string tulajdonságokra helyezhetünk el.

// [NotNull] -nem lehet null a string
// [Length(min, max)] -min és max között kell, hogy legyen a hossza
// [StartUpperCase] -nagy betűvel kell kezdődnie

// A függvény fogadjon egy tetszőleges típusú listát és csak azokat az elemeket adja vissza belőle,
// amelyek minden tulajdonsága minden validációs kritériumnak megfelelt!


using System.Reflection;
using Validator;

List<Person> people = new List<Person>()
{
    new Person("John", "driver"), //ok
    new Person("james", "teacher"), //nok
    new Person("Al", "actor"), //nok
    new Person("Kate", "musical singer"), //nok
    new Person("Sarah", "trainer") //ok
};

var valids = Validate(people);
;

List<T> Validate<T>(IEnumerable<T> items)
{
    List<T> valids = new List<T>();
    Type t = typeof(T);

    foreach (var item in items)
    {
        bool valid = true;

        foreach (var prop in t.GetProperties())
        {
            var attrs = prop.GetCustomAttributes();
            var propValue = prop.GetValue(item);
            foreach (var attr in attrs)
            {
                if (attr is NotNullAttribute && propValue == null)
                {
                    valid = false;
                }
                else if (attr is StartUpperCase && !char.IsUpper(propValue.ToString()[0]))
                {
                    valid = false;
                }
                else if (attr is LengthAttribute)
                {
                    int min = (attr as LengthAttribute).Min;
                    int max = (attr as LengthAttribute).Max;
                    if (!(propValue.ToString().Length >= min && propValue.ToString().Length <= max))
                    {
                        valid = false;
                    }
                }
            }
        }

        if (valid)
        {
            valids.Add(item);
        }
    }
    return valids;
    
}


