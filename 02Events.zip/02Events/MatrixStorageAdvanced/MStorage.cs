﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatrixStorageAdvanced
{
    public class MStorage<T>
    {
        public class ItemAddedEventArgs : EventArgs
        {
            public ItemAddedEventArgs(T item, int row, int column)
            {
                Item = item;
                Row = row;
                Column = column;
            }

            public T Item { get; }
            public int Row { get; }
            public int Column { get; }
        }

        public class MatrixIndexEventArgs : EventArgs
        {
            public int Index { get; }

            public MatrixIndexEventArgs(int index)
            {
                Index = index;
            }
        }


        public event EventHandler<MatrixIndexEventArgs> RowFull;
        public event EventHandler<MatrixIndexEventArgs> ColumnFull;
        public event EventHandler MatrixFull;
        public event EventHandler<ItemAddedEventArgs> ItemAdded;

        T[,] matrix;
        int count = 0;
        int capacity = 0;
        Random r = new Random();
        public MStorage(int row, int column)
        {
            this.matrix = new T[row, column];
            capacity = row * column;
        }

        public void Add(T item)
        {
            if (count < capacity)
            {
                int[] result = FindPlace();

                bool rfBefore = IsThisRowFull(result[0]);
                bool cfBefore = IsThisColumnFull(result[1]);

                this.matrix[result[0], result[1]] = item;
                ItemAdded?.Invoke(this, new ItemAddedEventArgs(item, result[0], result[1]));

                bool rfAfter = IsThisRowFull(result[0]);
                bool cfAfter = IsThisColumnFull(result[1]);

                if (rfBefore != rfAfter)
                {
                    RowFull?.Invoke(this, new MatrixIndexEventArgs(result[0]));
                }

                if (cfBefore != cfAfter)
                {
                    ColumnFull?.Invoke(this, new MatrixIndexEventArgs(result[1]));
                }

                count++;
                if (capacity == count)
                {
                    MatrixFull?.Invoke(this, new EventArgs());
                }
            }
            else
            {
                throw new Exception("Matrix is full!");
            }

        }

        private int[] FindPlace()
        {
            //return: [row,column]
            int row = -1;
            int column = -1;
            do
            {
                row = r.Next(0, this.matrix.GetLength(0));
                column = r.Next(0, this.matrix.GetLength(1));
            } while (this.matrix[row, column] != null);
            return new int[] { row, column };
        }

        private bool IsThisColumnFull(int index)
        {
            bool full = true;
            for (int i = 0; i < this.matrix.GetLength(0); i++)
            {
                if (this.matrix[i, index] == null)
                {
                    full = false;
                }
            }
            return full;
        }

        private bool IsThisRowFull(int index)
        {
            bool full = true;
            for (int j = 0; j < this.matrix.GetLength(1); j++)
            {
                if (this.matrix[index, j] == null)
                {
                    full = false;
                }
            }
            return full;
        }
    }
}
