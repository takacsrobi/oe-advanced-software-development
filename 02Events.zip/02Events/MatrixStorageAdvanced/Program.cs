﻿//Az eseményeket EventHandler<T> típusként hozzuk létre és készítsük el a szükséges
//eseményparaméter osztályokat!


using MatrixStorageAdvanced;

MStorage<string> st = new MStorage<string>(3, 3);

st.MatrixFull += MatrixFullToDisplay;
st.RowFull += RowFullToDisplay;
st.ColumnFull += ColumnFullToDisplay;
st.ItemAdded += ItemAddedToDisplay;

void ItemAddedToDisplay(object? sender, MStorage<string>.ItemAddedEventArgs e)
{
    Console.WriteLine(e.Item + " added: " + e.Row + ", " + e.Column);
}

void ColumnFullToDisplay(object sender, MStorage<string>.MatrixIndexEventArgs e)
{
    Console.WriteLine("Column full: " + e.Index);
}

void RowFullToDisplay(object sender, MStorage<string>.MatrixIndexEventArgs e)
{
    Console.WriteLine("Row full: " + e.Index);
}

void MatrixFullToDisplay(object sender, EventArgs e)
{
    Console.WriteLine("Matrix is full!");
}

st.Add("London");
st.Add("New York");
st.Add("Chicago");
st.Add("Athen");
st.Add("Manchester");
st.Add("Berlin");
st.Add("Budapest");
st.Add("Warsaw");
st.Add("Wien");



