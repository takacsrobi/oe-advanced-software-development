﻿//Készítsünk egy generikus Matrix<T> osztályt, amelynek konstruktorában lehessen megadni
//a sorok és oszlopok számát!

//Amikor be szeretnénk szúrni egy elemet, akkor egy random helyre jöjjön létre! 

//Az alábbi eseményeket biztosítsa a mátrix:
//- RowFull
//- ColumnFull
//- MatrixFull


using MatrixStorage;

MStorage<string> st = new MStorage<string>(3, 3);

st.MatrixFull += MatrixFullToDisplay;
st.RowFull += RowFullToDisplay;
st.ColumnFull += ColumnFullToDisplay;
st.ItemAdded += ItemAddedToDisplay;

void ItemAddedToDisplay(string item, int row, int column)
{
    Console.WriteLine(item + " added: " + row + "," + column);
}

void ColumnFullToDisplay(int index)
{
    Console.WriteLine("Column full: " + index);
}

void RowFullToDisplay(int index)
{
    Console.WriteLine("Row full: " + index);
}

void MatrixFullToDisplay()
{
    Console.WriteLine("Matrix is full!");
}

st.Add("London");
st.Add("New York");
st.Add("Chicago");
st.Add("Athen");
st.Add("Manchester");
st.Add("Berlin");
st.Add("Budapest");
st.Add("Warsaw");
st.Add("Wien");



