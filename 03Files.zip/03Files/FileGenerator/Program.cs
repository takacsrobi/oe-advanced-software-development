﻿//A csatolt fájlban telephelyeket, szervezeti egységeket és azokon belül személyeket tárolunk. 

//Hozzon létre minden telephelynek mappákat, azokon belül a szervezeti egységeknek is mappákat.
//Ezeken belül minden dolgozónak a nevére hozzon létre vezetéknév_keresztnév.log nevű fájlt!


using FileGenerator;

string[] lines = File.ReadAllLines("input.txt");

List<Location> location = new List<Location>();

Import(lines, location);
Generator(location);

static void Import(string[] lines, List<Location> location)
{
    foreach (var line in lines)
    {
        if (line.StartsWith("#"))
        {
            location.Add(new Location()
            {
                Name = line.Substring(1)
            });
        }
        else if (line.StartsWith("\t>"))
        {
            location.Last().Departments.Add(new Department()
            {
                Name = line.Substring(2)
            });
        }
        else if (line.StartsWith("\t\t-"))
        {
            location.Last().Departments.Last().People.Add(new Person()
            {
                Name = line.Substring(3)
            });
        }
    }
}

static void Generator(List<Location> location)
{
    string path = Path.Combine("e:", "workers");

    foreach (var loc in location)
    {
        Directory.CreateDirectory(Path.Combine(path, loc.Name));
        foreach (var dept in loc.Departments)
        {
            Directory.CreateDirectory(Path.Combine(path, loc.Name, dept.Name));
            foreach (var person in dept.People)
            {
                File.Create(Path.Combine(path, loc.Name, dept.Name, person.Name + ".log"));
            }
        }
    }
}

