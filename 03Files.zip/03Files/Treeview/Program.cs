﻿//Készítsünk egy fájl és mappastruktúra megjelenítő alkalmazást,
//amely egy fa struktúraként jeleníti meg a mappákat és fájlokat!
//Lehessen megadni, hogy mekkora mélységig menjen le!


string path = @"E:\workers";
ShowDirectory(path);



static void ShowDirectory(string path, int level = 0)
{
    var di = new DirectoryInfo(path);

    Console.WriteLine(new string(' ', level) + "[" + di.Name + "]");

    var directories = di.GetDirectories();
    foreach (var dir in directories)
    {
        ShowDirectory(dir.FullName, level+1);
    }

    var files = di.GetFiles();
    foreach (var file in files)
    {
        Console.WriteLine(new string(' ', level+1) + file.Name);
    }
}