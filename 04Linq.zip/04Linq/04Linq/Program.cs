﻿// Készítsünk egy Student osztályt, ahol az eltárolandó tulajdonságok:
// name, height, mark. Hozzunk létre két gyűjteményt, legyenek bennük közös elemek.
// Ezeknek adjuk meg a:

// - metszetét
// - unióját
// - különbségét


using _04Linq;

var students = new Student[]
{
    new Student("John", 182, 4),
    new Student("Liza", 166, 5),
    new Student("Carlos", 177, 3),
    new Student("James", 185, 4),
    new Student("Jack", 156, 2),
    new Student("Kate", 174, 5),
};


List<Student> groupA = new List<Student>();

List<Student> groupB = new List<Student>();

groupA.Add(students[0]);
groupA.Add(students[1]);
groupA.Add(students[2]);
groupA.Add(students[3]);

groupB.Add(students[0]);
groupB.Add(students[4]);
groupB.Add(students[5]);
groupB.Add(students[3]);

var intersect = groupA.Intersect(groupB);

var union = groupA.Union(groupB);

var diff = groupA.Except(groupB);


// Írjuk meg a lekérdezéseket az alábbi feladatokra:

// - Van-e 180 cm-nél magasabb gyerek?
// - Igaz-e, hogy senki nem bukott meg?
// - Kik a 3-asnál jobb tanulók?
// - Hányan magasabbak 170 cm-nél?
// - Ki a legjobb tanuló?
// - Ki a 3 legjobb tanuló?
// - Mi a 3 legjobb tanuló neve?

var q1 = students.Any(t => t.Height > 180);
var q2 = students.All(t => t.Mark > 1);
var q3 = students.Where(t => t.Mark > 3);
var q4 = students.Count(t => t.Height > 170);
var q5 = students.OrderByDescending(t => t.Mark).First();
var q6 = students.OrderByDescending(t => t.Mark).Take(3);
var q7 = students.OrderByDescending(t => t.Mark).Take(3).Select(t => t.Name);
