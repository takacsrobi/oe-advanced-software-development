﻿// Készítsük el az alábbi adatbázist:

// - személyek
// - értékelések(minden személynek több egyedi értékelése van ami szöveges és számszerű is)
// - díjak(egy személy több díjat is kaphatott, egy díjat többen is megkaphattak)

// Készítsünk seed adatokat!
// Készítsünk CRUD metódusokat mindenre!

using _11CodeFirst.Data;
using _11CodeFirst.Models;
using _11CodeFirst.Repository;

var ctx = new RatingDbContext();
var repo = new RatingRepository(ctx);

var q1 = repo.PeopleOrderByRatings();
var q2 = repo.MostCommonPrize();
var q3 = repo.MostPrestigiousPrize();

;





