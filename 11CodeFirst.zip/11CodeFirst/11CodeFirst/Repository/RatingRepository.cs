﻿using _11CodeFirst.Data;
using _11CodeFirst.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11CodeFirst.Repository
{
    public class RatingRepository
    {
        RatingDbContext ctx;

        public RatingRepository(RatingDbContext ctx)
        {
            this.ctx = ctx;
            SeedDatabase();
        }

        private void SeedDatabase()
        {
            var prizes = new Prize[]
            {
                new Prize("Employee of the year"),
                new Prize("Most talented employee"),
                new Prize("Loyalty prize")
            };

            ctx.Prizes.AddRange(prizes);
            ctx.SaveChanges();

            var people = new Person[]
            {
                new Person("John", 33),
                new Person("James", 42),
                new Person("Kate", 28),
                new Person("Sarah", 43)
            };

            ctx.People.AddRange(people);
            ctx.SaveChanges();


            people[2].Prizes.Add(prizes[0]);
            people[0].Prizes.Add(prizes[1]);
            people[1].Prizes.Add(prizes[2]);
            people[2].Prizes.Add(prizes[1]);
            people[1].Prizes.Add(prizes[1]);
            people[0].Prizes.Add(prizes[2]);

            ctx.SaveChanges();

            var ratings = new Rating[]
            {
                new Rating("Very kind", 5, people[0].Id),
                new Rating("Very smart", 4, people[0].Id),
                new Rating("Helpful", 4, people[1].Id),
                new Rating("Nervous sometimes...", 2, people[1].Id),
                new Rating("Smart but bossy", 3, people[2].Id),
                new Rating("Live him!", 5, people[3].Id)
            };

            ctx.Ratings.AddRange(ratings);

            ctx.SaveChanges();
        }

        public void CreatePerson(Person p)
        {
            ctx.People.Add(p);
            ctx.SaveChanges();
        }

        public void DeletePerson(string id)
        {
            var personToDelete = ctx.People.FirstOrDefault(t => t.Id == id);
            ctx.People.Remove(personToDelete);
            ctx.SaveChanges();
        }

        public IEnumerable<Person> ReadAllPerson()
        {
            return ctx.People;
        }

        public void UpdatePerson(Person p)
        {
            var personToUpdate = ctx.People.FirstOrDefault(t => t.Id == p.Id);
            personToUpdate.Name = p.Name;
            personToUpdate.Age = p.Age;
            ctx.SaveChanges();
        }

        public void AddRatingToPerson(string personId, Rating r)
        {
            r.PersonId = personId;
            ctx.Ratings.Add(r);
            ctx.SaveChanges();
        }

        //Készítsük el az alábbi lekérdezéseket:



        // - Személyek átlagos értékelések szerint csökkenő sorrendben
        public IEnumerable<Person> PeopleOrderByRatings()
        {
            return ctx.People.OrderByDescending(z => z.Ratings.Average(t => t.Mark));
        }

        // - Mely díjat osztották ki legtöbbször?
        public Prize MostCommonPrize()
        {
            return ctx.Prizes.OrderByDescending(t => t.People.Count).First();
        }


    }
}
