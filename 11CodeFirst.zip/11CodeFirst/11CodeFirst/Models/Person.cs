﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11CodeFirst.Models
{
    public class Person
    {
        public Person(string name, int age)
        {
            Name = name;
            Age = age;
            Id = Guid.NewGuid().ToString();
            Ratings = new HashSet<Rating>();
            Prizes = new HashSet<Prize>();
        }

        public Person()
        {
            Ratings = new HashSet<Rating>();
            Prizes = new HashSet<Prize>();
        }

        [StringLength(100)]
        public string Name { get; set; }

        public int Age { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string Id { get; set; }

        public virtual ICollection<Rating> Ratings { get; set; }

        public virtual ICollection<Prize> Prizes { get; set; }
    }
}
