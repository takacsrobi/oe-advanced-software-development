﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11CodeFirst.Models
{
    public class Prize
    {
        public Prize(string name)
        {
            Id = Guid.NewGuid().ToString();
            Name = name;
            People = new HashSet<Person>();
        }

        public Prize()
        {
            People = new HashSet<Person>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string Id { get; set; }

        [StringLength(100)]
        public string Name { get; set; }

        public virtual ICollection<Person> People { get; set; }
    }
}
