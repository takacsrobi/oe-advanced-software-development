﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11CodeFirst.Models
{
    public class Rating
    {
        public Rating(string text, int mark, string personId)
        {
            Id = Guid.NewGuid().ToString();
            Text = text;
            Mark = mark;
            PersonId = personId;
        }

        public Rating()
        {
            
        }

        public string PersonId { get; set; }

        public virtual Person Person { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string Id { get; set; }

        [StringLength(500)]
        public string Text { get; set; }

        public int Mark { get; set; }
    }
}
