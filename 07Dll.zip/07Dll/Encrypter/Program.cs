﻿// Készítsünk egy osztálykönyvtárat a Cézár titkosítás implementálására!

// Legyen egy Encrypt() és egy Decrypt() metódusa, amely a bemeneti szövegek
// karaktereit a megadott kulccsal képes eltolni az UTF-16 kódtáblában!

using SpecialEncryption;

CaesarEncryption enc = new CaesarEncryption(10);

string secret = enc.Encrypt("Ma szépen süt a nap!");

string original = enc.Decrypt(secret);

