﻿//http://web.archive.org/web/20230208025547/https://www.pinvoke.net/default.aspx/user32/MessageBox.html

// Készítsünk egy alkalmazást, amely megjelenít egy teendő listát!
// Legyünk képesek a végére újabb teendőket felvinni
// Üres felvitel esete jelentse a program végét
// A program ekkor egy felugró MessageBox segítségével kérdezze meg, hogy szeretnénk-e menteni

using System.Runtime.InteropServices;




var todos = File.ReadAllLines("todo.txt").ToList();

foreach (var item in todos)
{
    Console.WriteLine(item);
}

string input = "";
do
{
    input = Console.ReadLine();
    if (input != "")
    {
        todos.Add(input);
    }
    
} while (input != "");


int result = MessageBox(0, "Szeretnéd menteni?", "Mentés", 4);
if (result == 6)
{
    File.WriteAllLines("todo.txt", todos.ToArray());
}


[DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
static extern int MessageBox(IntPtr hWnd, String text, String caption, uint type);