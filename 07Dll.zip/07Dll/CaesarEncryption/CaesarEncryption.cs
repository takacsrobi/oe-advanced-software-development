﻿namespace SpecialEncryption
{
    public class CaesarEncryption
    {
        int key = 0;

        public CaesarEncryption(int key)
        {
            this.key = key;
        }

        public string Encrypt(string input)
        {
            string output = "";
            for (int i = 0; i < input.Length; i++)
            {
                output += (char)(input[i] + key);
            }
            return output;
        }

        public string Decrypt(string input)
        {
            string output = "";
            for (int i = 0; i < input.Length; i++)
            {
                output += (char)(input[i] - key);
            }
            return output;
        }
    }
}