﻿//Készítsünk relfexióval egy olyan függvényt, amely tetszőleges típusú lista elemeit
//képes táblázatosan megjeleníteni!


using System.Drawing;
using System.Reflection;


List<Person> people = new List<Person>()
{
    new Person("John", 35),
    new Person("James", 42),
    new Person("Kate", 28),
};

List<Point> points = new List<Point>()
{
    new Point(10,20),
    new Point(7,30),
    new Point(-2,15),
};

ToTable(people);
Console.WriteLine();
Console.WriteLine();

ToTable(points);

void ToTable<T>(IEnumerable<T> items)
{
    Type t = typeof(T);
	foreach (var prop in t.GetProperties())
	{
        Console.Write(prop.Name + "\t\t");
    }
    Console.WriteLine();

    foreach (var item in items)
    {
        foreach (var prop in t.GetProperties())
        {
            Console.Write(prop.GetValue(item) + "\t\t");
        }
        Console.WriteLine();
    }
}

class Person
{
    public Person(string name, int age)
    {
        Name = name;
        Age = age;
    }

    public string Name { get; set; }

    public int Age { get; set; }
}
