﻿// Készítsünk egy olyan függvényt, amely tetszőleges gyűjteményt képes XML fájlba menteni!

using System.Drawing;
using System.Xml.Linq;

List<Person> people = new List<Person>()
{
    new Person("John", 35),
    new Person("James", 42),
    new Person("Kate", 28),
};

List<Point> points = new List<Point>()
{
    new Point(10,20),
    new Point(7,30),
    new Point(-2,15),
};

ToXml(people, "people.xml");
ToXml(points, "points.xml");

void ToXml<T>(IEnumerable<T> items, string path)
{
    Type t = typeof(T);
    XDocument xdoc = new XDocument();
    XElement root = new XElement(t.Name + "s");
    xdoc.Add(root);

    foreach (var item in items)
    {
        XElement sub = new XElement(t.Name);

        foreach (var prop in t.GetProperties())
        {
            sub.Add(new XAttribute(prop.Name, prop.GetValue(item)));
        }

        root.Add(sub);
    }

    xdoc.Save(path);
}

class Person
{
    public Person(string name, int age)
    {
        Name = name;
        Age = age;
    }

    public string Name { get; set; }

    public int Age { get; set; }
}
